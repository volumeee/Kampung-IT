SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: artikel
#

DROP TABLE IF EXISTS `artikel`;

CREATE TABLE `artikel` (
  `artikel_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` varchar(128) NOT NULL,
  `link` varchar(150) NOT NULL,
  `tgl_upload` datetime NOT NULL,
  `judul` varchar(100) NOT NULL,
  `banner` varchar(500) NOT NULL DEFAULT 'default-banner-infaq-online-4x4.jpg',
  `isi` text NOT NULL,
  `dilihat` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`artikel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `artikel` (`artikel_id`, `user_email`, `link`, `tgl_upload`, `judul`, `banner`, `isi`, `dilihat`) VALUES ('1', 'admin@gmail.com', 'about-us', '2022-10-19 17:04:41', 'About Us', 'blog-header-design.jpg', '<h2>Judul Perangkat Lunak</h2>\r\n\r\n<p>Perangkat lunak yang akan dibangun dan dikembangkan berjudul : KampungIT : Tempat Mencari Kerja Bagi Masyarakat Kampung. Dengan mengusung slogan &quot;Take Your Job Easly&quot;, perangkat lunak ini diharapkan mampu mempermudah bagi penyedia jasa khususnya di perkampungan dan umumnya kepada masyarakat luas</p>\r\n\r\n<h2>Latar Belakang Ide Perangkat Lunak</h2>\r\n\r\n<p>Selama pandemi COVID-19 penggunaan teknologi telah meningkat secara signifikan dan memberikan pengaruh yang besar bagi masyarakat khususnya dalam ruang digital. Penyebaran virus Covid-19 yang begitu pesat hingga dari epidemi menjadi pandemi telah memaksa segala kegiatan yang awalnya dilaksanakan secara tatap muka harus dialihkan dengan kebijakan baru dari pemerintah yaitu bekerja dari rumah atau dikenal dengan istilah work from home. Sebagai langkah adaptasi terhadap perubahan tersebut, teknologi menjadi pilihan terbaik agar kegiatan tetap dapat terlaksana secara digital sehingga tidak heran terjadi peningkatan yang besar di bidang teknologi.</p>\r\n\r\n<p>Meskipun masyarakat saat ini telah menggunakan berbagai teknologi dalam kegiatan produktif, terdapat beberapa kegiatan dagang yang belum tersentuh teknologi secara maksimal terutama di daerah perkampungan. Berdasarkan banyaknya pengguna teknologi berbasis internet dan keunggulan dalam memberikan peluang yang besar, maka perlu ada pengembangan teknologi di daerah perkampungan untuk mendukung peningkatan ekonomi masyarakat setempat. Sehingga pemulihan ekonomi pasca pandemi tak hanya terjadi di kota-kota besar saja melainkan juga lokal seperti kampung.&nbsp;</p>\r\n\r\n<p>Oleh karena itu, pada penelitian ini kami mengembangkan sebuah sistem berbasis web untuk menyediakan tempat bagi masyarakat di suatu kampung dalam menawarkan jasa atau pekerjaan secara online. Sistem ini dilengkapi dengan berbagai fitur seperti membuat postingan jasa, fitur chat, dan rating. Diharapkan, sistem yang kami kembangkan tersebut dapat bermanfaat bagi masyarakat dalam upaya pemulihan ekonomi dan peningkatan ekonomi masyarakat lokal.</p>\r\n\r\n<h2>Batasan Masalah</h2>\r\n\r\n<ol>\r\n	<li>Kampung IT menyediakan tempat untuk menjual jasa bagi masyarakat kampung khususnya, dan umumnya pada masyarakat luas.</li>\r\n	<li>Dilengkapi fitur chat untuk mempermudah komunikasi dan menjalin kepercayaan antar pengguna dan penyedia jasa.</li>\r\n	<li>Kampung IT juga menyediakan rate untuk setiap jasa yang dijual sehingga pengguna dapat memilih penyedia jasa yang sesuai kebutuhan dan memiliki kinerja yang baik.</li>\r\n</ol>', '0');
INSERT INTO `artikel` (`artikel_id`, `user_email`, `link`, `tgl_upload`, `judul`, `banner`, `isi`, `dilihat`) VALUES ('2', 'admin@gmail.com', 'registrasi-akun', '2022-10-20 12:55:35', 'Registrasi Akun', 'registration-on-site-access-to-account-vector.jpg', '<p>Halo teman-teman, semoga semua dalam keadaan baik-baik saja ya. Pada kesempatan kali ini akan dibahas mengenai cara membuat akun di website Kampung IT,&nbsp; caranya cukup mudah dan cepat. Hal pertama yang harus disiapkan adalah email aktif milih Sobat, karena setelah registrasi akan dimintai kode yang dikirim ke email terdaftar untuk mengaktifkan akun.</p>\r\n\r\n<p>Tidak perlu menunggu lama, berikut adalah tutorial membuat akun pada website Kampung IT,</p>\r\n\r\n<ol>\r\n	<li>Buka halaman &#39;Home&#39; dari Kampung IT, lalu Sobat cari icon yang berbentuk seperti tombol power pada navbar atas.</li>\r\n	<li>Nantinya akan diarahkan ke halaman login, namun jika belum memiliki akun Sobat bisa memilih menu registrasi.</li>\r\n	<li>Masukkan Nama, Email, dan Password.</li>\r\n	<li>Setelah itu sistem akan mengirimkan kode untuk mengaktifkan akun, catat kode tersebut dan masukkan ke bagian registrasi akun.</li>\r\n	<li>Kode hanya valid selama satu jam, dan apabila kode yang dimasukkan sesuai maka user diperbolehkan masuk ke sistem.</li>\r\n	<li>Proses registrasi akun selesai.</li>\r\n</ol>\r\n\r\n<p>Nah, seperti itu tutorialnya Sobat, sangat mudah dan cepat ya. Semoga dapat bermanfaat dan terima kasih.</p>', '0');
INSERT INTO `artikel` (`artikel_id`, `user_email`, `link`, `tgl_upload`, `judul`, `banner`, `isi`, `dilihat`) VALUES ('3', 'admin@gmail.com', 'registrasi-merchant-penyedia-jasa', '2022-10-21 06:56:03', 'Registrasi Merchant (Penyedia Jasa)', 'mix.jpg', '<p>Halo teman-teman, semoga semua dalam keadaan baik-baik saja ya. Pada kesempatan kali ini akan dibahas mengenai cara menjadi penyedia jasa atau di website Kampung IT dikenal dengan nama <strong>&quot;merchant</strong>&quot;,&nbsp; caranya cukup mudah dan cepat. Hal pertama yang harus disiapkan adalah harus sudah memiliki akun di Kampung IT.</p>\r\n\r\n<p>Tahap registrasi pengajuan penyedia jasa dibagi menjadi dua tahap,</p>\r\n\r\n<ol>\r\n	<li>Memasukkan identitas umum sebagai penyedia jasa, meliputi : nama bisnis, kategori bisnis, alamat bisnis, dan deskripsi bisnis.</li>\r\n	<li>Melakukan aktivasi merchant dengan memasukkan token yang dikirim ke email akun.</li>\r\n</ol>\r\n\r\n<p>Tidak perlu menunggu lama, berikut adalah tutorial membuat bergabung sebagai penyedia jasa pada website Kampung IT,</p>\r\n\r\n<ol>\r\n	<li>Login ke akun, maka akan diarahkan ke halaman detail user. Jika ternyata beluh diarahkan otomatis, maka pilih profile pada kanan atas dan pilih My Profile.</li>\r\n	<li>Memasukkan identitas umum sebagai penyedia jasa, meliputi : nama bisnis, kategori bisnis, alamat bisnis, dan deskripsi bisnis.</li>\r\n	<li>Setelah melakukan aktivasi akun dengan mengisi kode token yang dikirim ke email akun.</li>\r\n	<li>Jika aktivasi berhasil, maka akan diarahkan untuk login ulang.</li>\r\n	<li>Selamat, sekarang Anda sudah menjadi penyedia jasa.</li>\r\n</ol>\r\n\r\n<p>Nah, seperti itu tutorialnya Sobat, sangat mudah dan cepat ya. Semoga dapat bermanfaat dan terima kasih.</p>', '0');


#
# TABLE STRUCTURE FOR: chat
#

DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `chat_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `status` int(1) NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: identitas
#

DROP TABLE IF EXISTS `identitas`;

CREATE TABLE `identitas` (
  `id_iden` int(2) NOT NULL,
  `nama_instansi` varchar(100) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `alamat` varchar(250) NOT NULL,
  `email` varchar(100) NOT NULL,
  `favicon` varchar(500) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `logo` varchar(500) DEFAULT NULL,
  `deskripsi` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `identitas` (`id_iden`, `nama_instansi`, `no_telp`, `alamat`, `email`, `favicon`, `icon`, `logo`, `deskripsi`) VALUES ('1', 'Kampung IT', '+032 3456 7890', 'Fakultas Ilmu Komputer Universitas Duta Bangsa, Jl. Bhayangkara No.55, Tipes, Kec. Serengan, Kota Surakarta, Jawa Tengah 57154', 'kampungit.offc@gmail.com', 'default.ico', 'briefcase', 'KampungIT_-_logo.png', 'take your job easly');


#
# TABLE STRUCTURE FOR: inbox
#

DROP TABLE IF EXISTS `inbox`;

CREATE TABLE `inbox` (
  `inbox_id` varchar(15) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pesan` text NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`inbox_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `inbox` (`inbox_id`, `nama`, `email`, `pesan`, `datetime`) VALUES ('IBX221020001', 'Yusuf Bahtiar', '202030292@mhs.udb.ac.id', 'Halo Admin, ini adalah pesan percobaan. Semoga semua dalam keadaan sehat dan sukses selalu, terima kasih.', '2022-10-20 11:14:53');


#
# TABLE STRUCTURE FOR: kategori
#

DROP TABLE IF EXISTS `kategori`;

CREATE TABLE `kategori` (
  `kategori_id` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`kategori_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `kategori` (`kategori_id`, `kategori`) VALUES ('1', 'Jasa Angkut');
INSERT INTO `kategori` (`kategori_id`, `kategori`) VALUES ('2', 'Tukang Bangunan');
INSERT INTO `kategori` (`kategori_id`, `kategori`) VALUES ('3', 'Buruh Harian Lepas');
INSERT INTO `kategori` (`kategori_id`, `kategori`) VALUES ('4', 'Laundry');
INSERT INTO `kategori` (`kategori_id`, `kategori`) VALUES ('5', 'Dapur Makanan');
INSERT INTO `kategori` (`kategori_id`, `kategori`) VALUES ('6', 'Tukang Pijit');


#
# TABLE STRUCTURE FOR: merchant
#

DROP TABLE IF EXISTS `merchant`;

CREATE TABLE `merchant` (
  `merchant_id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_usaha` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `kategori` varchar(200) NOT NULL,
  `alamat` varchar(300) NOT NULL,
  `deskripsi` text NOT NULL,
  `is_active` int(1) NOT NULL,
  PRIMARY KEY (`merchant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `merchant` (`merchant_id`, `nama_usaha`, `email`, `kategori`, `alamat`, `deskripsi`, `is_active`) VALUES ('1', 'Jagoan Kirim Kilat', 'info.infaqonline@gmail.com', '1', 'Bekonang', 'ok', '1');


#
# TABLE STRUCTURE FOR: post
#

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` varchar(18) NOT NULL,
  `email` varchar(200) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `banner` varchar(500) NOT NULL,
  `text` text NOT NULL,
  `tarif` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `dilihat` int(11) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `post` (`post_id`, `email`, `judul`, `banner`, `text`, `tarif`, `datetime`, `dilihat`) VALUES ('PST2210210013', 'info.infaqonline@gmail.com', 'Jasa Angkut dan Kirim Barang Menggunakan Truk', 'b5f12bcf-c6de-4367-9bd1-bc9cb8ebc686.jpg', '<p>Nominal tarif bisa berubah sesuai tujuan, info : +3272748 2343 atau melalui chat</p>', '300000', '2022-10-21 15:58:30', '0');
INSERT INTO `post` (`post_id`, `email`, `judul`, `banner`, `text`, `tarif`, `datetime`, `dilihat`) VALUES ('PST2210210027', 'info.infaqonline@gmail.com', 'Angkut Muatan L300', 'col300.jpg', '<p>Mesin kuat aman, tarif terjangkau</p>', '150000', '2022-10-21 18:23:54', '0');


#
# TABLE STRUCTURE FOR: review
#

DROP TABLE IF EXISTS `review`;

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_rating` int(1) NOT NULL,
  `user_review` text NOT NULL,
  `datetime` int(11) NOT NULL,
  PRIMARY KEY (`review_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `no_telp` varchar(15) DEFAULT NULL,
  `alamat` varchar(150) DEFAULT NULL,
  `image` varchar(128) NOT NULL DEFAULT 'default.jpg',
  `password` varchar(256) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL,
  `date_created` int(11) NOT NULL,
  `last_login` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id`, `name`, `username`, `email`, `no_telp`, `alamat`, `image`, `password`, `role_id`, `is_active`, `date_created`, `last_login`) VALUES ('1', 'Admin', 'admin', 'kampungit.offc@gmail.com', '', '', 'default.jpg', '$2y$10$XR2C./ESawnYWfsb7y9NQ.CR5iKnvulCAhriXHT0xxfXPrvrEiP1.', '1', '1', '1587030576', '1666367898');
INSERT INTO `user` (`id`, `name`, `username`, `email`, `no_telp`, `alamat`, `image`, `password`, `role_id`, `is_active`, `date_created`, `last_login`) VALUES ('2', 'User', 'user', 'info.infaqonline@gmail.com', '', '', 'default.jpg', '$2y$10$WiDX9h7lToAVoyk3CqKztuppHGOOqVYYhQvxI4a0Q0Ru2VMeKXBsu', '2', '1', '1602322568', '1666367817');


#
# TABLE STRUCTURE FOR: user_access_menu
#

DROP TABLE IF EXISTS `user_access_menu`;

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES ('1', '1', '1');
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES ('2', '1', '2');
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES ('3', '2', '2');
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES ('4', '1', '3');
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES ('5', '2', '4');
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES ('6', '3', '2');
INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES ('7', '3', '5');


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `user_menu` (`id`, `menu`) VALUES ('1', 'Admin');
INSERT INTO `user_menu` (`id`, `menu`) VALUES ('2', 'User');
INSERT INTO `user_menu` (`id`, `menu`) VALUES ('3', 'Menu');
INSERT INTO `user_menu` (`id`, `menu`) VALUES ('4', 'Merchant');
INSERT INTO `user_menu` (`id`, `menu`) VALUES ('5', 'Member');


#
# TABLE STRUCTURE FOR: user_role
#

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `user_role` (`id`, `role`) VALUES ('1', 'Administrator');
INSERT INTO `user_role` (`id`, `role`) VALUES ('2', 'Merchant');
INSERT INTO `user_role` (`id`, `role`) VALUES ('3', 'Pengunjung');


#
# TABLE STRUCTURE FOR: user_sub_menu
#

DROP TABLE IF EXISTS `user_sub_menu`;

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('1', '1', 'Dashboard', 'admin', 'fas fa-fw fa-tachometer-alt', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('2', '3', 'Menu User', 'menu', 'fas fa-fw fa-folder', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('3', '3', 'Submenu User', 'menu/submenu', 'fas fa-fw fa-folder-open', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('4', '1', 'Role', 'admin/role', 'fas fa-fw fa-user-shield', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('5', '1', 'Identitas', 'admin/identitas', 'fas fa-fw fa-id-card', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('6', '1', 'Artikel', 'admin/artikel', 'fas fa-fw fa-newspaper', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('7', '1', 'Kategori', 'admin/kategori', 'fas fa-fw fa-project-diagram', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('8', '4', 'Chat', 'merchant/chat', 'fas fa-fw fa-comments', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('9', '4', 'Posting', 'merchant/posting', 'fas fa-fw fa-newspaper', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('11', '4', 'My Merchant', 'merchant', 'fas fa-fw fa-store-alt', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('12', '1', 'Inbox', 'admin/inbox', 'fas fa-fw fa-envelope', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('13', '5', 'Chat', 'member', 'fas fa-fw fa-comments', '1');
INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES ('14', '5', 'History Rate', 'member/historyrate', 'fas fa-fw fa-trophy', '1');


#
# TABLE STRUCTURE FOR: user_token
#

DROP TABLE IF EXISTS `user_token`;

CREATE TABLE `user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `user_token` (`id`, `token`, `date_created`) VALUES ('1', '1125', '1666315311');


SET foreign_key_checks = 1;
